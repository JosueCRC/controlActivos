/**
 * APP.JS - SISTEMA VELE PROVINCIAL+ v2.0
 * Descripción: Gestión de activos institucionales con Firebase Firestore y Auth.
 * Estructura: 1. Configuración, 2. Auth, 3. UI/Temas, 4. Lógica de Datos (CRUD).
 */

import { db, activosRef, auth } from './config.js'; 
import { 
  onSnapshot, doc, addDoc, updateDoc, deleteDoc, query 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

import { 
  signInWithEmailAndPassword, onAuthStateChanged, signOut 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const { createApp, ref, computed, onUnmounted } = Vue;
const { createVuetify } = Vuetify;

// --- 1. CONFIGURACIÓN DE VUETIFY ---
const vuetify = createVuetify({
  theme: { defaultTheme: 'light' },
});




const app = createApp({
  setup() {
    
const limpiarTexto = (texto) => {
  if (!texto) return '';
  // Elimina etiquetas HTML como <script>, <img>, etc. para evitar inyecciones
  return texto.replace(/<[^>]*>?/gm, '').trim();
};


    // --- 2. ESTADO DE AUTENTICACIÓN Y SEGURIDAD ---
    const usuarioActivo = ref(null);
    const cargandoAuth = ref(true);
    const loginDatos = ref({ email: '', password: '' });
    const mostrarModalLogin = ref(false);

    /**
     * @function onAuthStateChanged
     * @description Observador de Firebase que detecta cambios en la sesión.
     */
    onAuthStateChanged(auth, (user) => {
      usuarioActivo.value = user;
      cargandoAuth.value = false;
    });

    /**
     * @function manejarLogin
     * @description Autentica al usuario con Firebase Auth.
     */
    const manejarLogin = async () => {
      try {
        estaCargando.value = true;
        await signInWithEmailAndPassword(auth, loginDatos.value.email, loginDatos.value.password);
        mostrarModalLogin.value = false;
        loginDatos.value = { email: '', password: '' };
      } catch (error) {
        let mensaje = "Error de autenticación. Intente de nuevo.";
        if (error.code === 'auth/too-many-requests') {
          mensaje = "Cuenta bloqueada temporalmente por demasiados intentos.";
        }
        alert(mensaje);
      } finally {
        estaCargando.value = false;
      }
    };

    /**
     * @function manejarLogout
     * @description Cierra la sesión activa en Firebase.
     */
    const manejarLogout = () => signOut(auth);

    /**
     * @property {Computed} esAdmin
     * @description Valida si existe un usuario autenticado para habilitar permisos.
     */
    const esAdmin = computed(() => !!usuarioActivo.value);

    const cancelarLogin = () => {
      mostrarModalLogin.value = false;
      loginDatos.value = { email: '', password: '' };
    };


    // --- 3. UI, TEMAS Y RECURSOS VISUALES ---
    const theme = Vuetify.useTheme();

    const icons = [
      { img: 'mdi-linkedin', link: 'https://www.linkedin.com/in/josue-gonzalez-barrios' },
      { img: 'mdi-email', link: 'mailto:jgonzalb@ccss.sa.cr' },
      { img: 'mdi-earth', link: '' }
    ];

    const cambiarTema = () => {
      theme.global.name.value = theme.global.current.value.dark ? 'light' : 'dark';
    };

    /**
     * @section Colores Dinámicos
     * @description Funciones para pintar badges y chips según el valor.
     */
    const pintarColorEstado = (condicion) => {
      if (condicion === 'EN USO') return 'green';
      if (condicion === 'RETIRADO') return 'red';
      return 'orange';
    };

    const pintarColorPlaca = (numPlaca) => {
      if (numPlaca === '100003') return 'red';
      if (numPlaca === '100004') return 'orange';
      return 'green';
    };


    // --- 4. GESTIÓN DE DATOS (CRUD & DASHBOARD) ---
    const listaActivos = ref([]);
    const terminoBusqueda = ref('');
    const estaCargando = ref(true);
    const mostrarDialogo = ref(false);
    const mostrarDetalle = ref(false);
    const detalleActivo = ref({});
    
    const itemPorDefecto = { 
      numPlaca: '', codBien: '', numSerie: '', marca: '', modelo: '', 
      unidadEjecutora: '2235-TI', fechaIngresoInv: '', fechaIngresoUnidad: '', 
      garantiaInicio: '', garantiaFin: '', descripcion: '', condicion: 'EN USO'
    };
    const modeloFormulario = ref({ ...itemPorDefecto });
    const esModoEdicion = ref(false);

    const columnasTabla = [
      { title: 'PLACA', key: 'numPlaca' },
      { title: 'CÓD. BIEN', key: 'codBien' },
      { title: 'INGRESO INV.', key: 'fechaIngresoInv' },
      { title: 'MARCA', key: 'marca' },
      { title: 'ESTADO', key: 'condicion', align: 'center' },
      { title: 'ACCIONES', key: 'acciones', align: 'end', sortable: false },
    ];

    /**
     * @function onSnapshot
     * @description Sincronización en tiempo real con Firestore.
     */
    const unsubscribe = onSnapshot(activosRef, (snapshot) => {
      listaActivos.value = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      estaCargando.value = false;
    }, (error) => {
      console.error("Error en snapshot:", error);
      estaCargando.value = false;
    });

    onUnmounted(() => unsubscribe());

    /**
     * @property {Computed} estadisticas
     * @description Calcula los totales para las tarjetas del Dashboard.
     */
    const estadisticas = computed(() => {
      const total = listaActivos.value.length || 0;
      const contar = (t) => listaActivos.value.filter(a => (a.condicion || "").toUpperCase() === t).length;

      const cantUso = contar('EN USO');
      const cantRep = contar('REPARACION');
      const cantRet = contar('RETIRADO');

      const calcPct = (valor) => total > 0 ? Math.round((valor / total) * 100) : 0;

      return [
        { title: 'Total Activos', valor: total, sub: 'Patrimonio Total', color: 'indigo-accent-4', icon: 'mdi-database', pct: 100 },
        { title: 'Operativos', valor: cantUso, sub: `${calcPct(cantUso)}% del inv.`, color: 'green-accent-4', icon: 'mdi-check-circle-outline', pct: calcPct(cantUso) },
        { title: 'En Talleres', valor: cantRep, sub: `${calcPct(cantRep)}% en mantenimiento`, color: 'amber-darken-1', icon: 'mdi-wrench-clock-outline', pct: calcPct(cantRep) },
        { title: 'Bajas/Retiros', valor: cantRet, sub: `${calcPct(cantRet)}% fuera`, color: 'red-accent-3', icon: 'mdi-archive-cancel-outline', pct: calcPct(cantRet) }
      ];
    });

    // --- 5. LOGICA DE FORMULARIOS ---

    const verFichaTecnica = (item) => {
      detalleActivo.value = { ...item };
      mostrarDetalle.value = true;
    };

    const abrirDialogoNuevo = () => {
      esModoEdicion.value = false;
      modeloFormulario.value = { ...itemPorDefecto };
      mostrarDialogo.value = true;
    };

    const abrirDialogoEdicion = (item) => {
      esModoEdicion.value = true;
      modeloFormulario.value = { ...item };
      mostrarDialogo.value = true;
    };

    
  /**
     * @function guardarActivo
     * @description Crea o actualiza un documento en Firestore con auditoría de usuario.
     * @enum {6} Sección de Lógica de Formularios y Seguridad.
     */
    const guardarActivo = async () => {
  if (!modeloFormulario.value.numPlaca) {
    alert("⚠️ El número de placa es obligatorio.");
    return;
  }

  estaCargando.value = true;

  // --- NUEVA LÓGICA DE SANITIZACIÓN ---
  // Creamos una copia limpia de los datos del formulario
  const datosSanitizados = {
    ...modeloFormulario.value,
    // Limpiamos campos de texto libre donde podrían inyectar código
    marca: limpiarTexto(modeloFormulario.value.marca),
    modelo: limpiarTexto(modeloFormulario.value.modelo),
    descripcion: limpiarTexto(modeloFormulario.value.descripcion || '')
  };

  const metadatos = {
    ultimaModificacion: new Date().toISOString(),
   modificadoPor: usuarioActivo.value?.email || 'Desconocido',
    versionApp: "2.0"
  };

  try {
    const placaNueva = datosSanitizados.numPlaca.toString().trim();

    if (!esModoEdicion.value) { 
      const existe = listaActivos.value.some(a => a.numPlaca?.toString().trim() === placaNueva);
      if (existe) {
        alert(`⚠️ ERROR: La placa ${placaNueva} ya existe.`);
        estaCargando.value = false;
        return;
      }

      // Guardamos la versión SANITIZADA
      await addDoc(activosRef, { 
        ...datosSanitizados, 
        creadoPor: usuarioActivo.value.email,
        ...metadatos 
      });
    } else {
      const { id, ...datosParaActualizar } = datosSanitizados;
      // Actualizamos con la versión SANITIZADA
      await updateDoc(doc(db, "Activos", id), { 
        ...datosParaActualizar, 
        ...metadatos 
      });
    }
    
    mostrarDialogo.value = false;
  } catch (e) { 
    console.error("Error al guardar:", e);
    alert("Error de seguridad o permisos.");
  } finally {
    estaCargando.value = false;
  }
};

    /**
     * @function eliminarActivo
     * @description Elimina físicamente un registro de la base de datos.
     */
   const eliminarActivo = async (id) => {
  // Verificación de "último minuto" directa contra el SDK de Auth, no contra una variable local
        if (!auth.currentUser) {
          alert("Acción no autorizada. Intento reportado.");
          return;
        }
        if (confirm('¿Confirma la eliminación?')) {
          await deleteDoc(doc(db, "Activos", id));
        }
      };
    // --- 6. RETORNO DE PROPIEDADES ---
    return {
      // Auth & User
      usuarioActivo, esAdmin, loginDatos, mostrarModalLogin, 
      manejarLogin, manejarLogout, cancelarLogin,

      // UI & Temas
      theme, icons, cambiarTema, pintarColorEstado, pintarColorPlaca, 
      
      // Datos & Listas
      listaActivos, terminoBusqueda, estaCargando, columnasTabla, estadisticas,
      
      // Modales y CRUD
      mostrarDialogo, mostrarDetalle, detalleActivo, modeloFormulario, esModoEdicion,
      verFichaTecnica, abrirDialogoNuevo, abrirDialogoEdicion, guardarActivo, eliminarActivo
    };
  }
});

app.use(vuetify).mount('#app');